// script.js

document.addEventListener('DOMContentLoaded', () => {
    const hamburgerMenu = document.getElementById('hamburgerMenu');
    const navLinks = document.getElementById('navLinks');

    hamburgerMenu.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    const registerForm = document.getElementById('registerForm');
    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(registerForm);
        const fullName = formData.get('Full Name');
        const email = formData.get('Email Address');
        const phone = formData.get('Phone Number');
        const dipDate = formData.get('dipDate');

        
    });
});
//.............................................

document.getElementById('hamburgerMenu').addEventListener('click', function () {
    const navLinks = document.getElementById('navLinks');
    navLinks.classList.toggle('show');
});

//--------------------------------------------------------------------------


  const scriptURL = "https://script.google.com/macros/s/AKfycbwe2b7XmgDw3tcKVYyZSfIYBS47MbY79UTN0S4gPa7TPEi-QfYXiD6G7XNjdDv0tdcJXg/exec"
  const form = document.forms['submit-to-google-sheet']

  form.addEventListener('submit', e => {
    e.preventDefault()
    fetch(scriptURL, { method: 'POST', body: new FormData(form)})
      .then(response => console.log('Success!', response))
      .catch(error => console.error('Error!', error.message))
  })



//--------------------------------------------------------------------------------------------------------------------
//redirect after submition
document.getElementById("registerForm").addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent default form submission

    // Get user input values
    const fullName = e.target.elements["Full-Name"].value;
    const dipDate = e.target.elements["dip-Date"].value;

    // Load the certificate template image
    const certificateImag = new Image();
    certificateImage.src = "certificate_template.jpg"; // Update this to your template's path

    certificateImage.onload = function () {
        // Create canvas
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");

        // Set canvas dimensions to match the image
        canvas.width = certificateImage.width;
        canvas.height = certificateImage.height;

        // Draw the certificate template
        ctx.drawImage(certificateImage, 0, 0, canvas.width, canvas.height);

        // Set text properties
        ctx.font = "94px 'Alex Brush', cursive"; // Font size and family
        ctx.fillStyle = "#000000"; // Black text color
        ctx.textAlign = "center"; // Center alignment

        // Calculate text positions
        const nameY = canvas.height / 2 - 50; // Position for the name
        const dateY = nameY + 70; // Position for the date (with 0.5 cm gap)

        // Add user's name to the certificate
        ctx.fillText(fullName, canvas.width / 2, nameY);

        // Add dip date to the certificate
        ctx.fillText(`Dip Date: ${dipDate}`, canvas.width / 2, dateY);

        // Convert canvas to data URL
        const dataUrl = canvas.toDataURL("image/jpeg", 1.0);

        // Detect if the user is on an iPhone
        const isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent);
        if (isIOS) {
            // Open certificate in a new tab for manual save
            const newTab = window.open();
            if (newTab) {
                newTab.document.body.innerHTML = `<img src="${dataUrl}" style="width:100%;max-width:600px;margin:0 auto;display:block;">`;
                alert("To save your certificate, long-press on the image and choose 'Save Image'.");
            } else {
                alert("Please allow popups to save your certificate.");
            }
        } else {
            // Trigger download for other devices
            const link = document.createElement("a");
            link.href = dataUrl;
            link.download = `${fullName}_Certificate.jpg`;
            link.click();
        }
    };

    certificateImage.onerror = function () {
        alert("Failed to load the certificate template. Please ensure the image path is correct.");
    };
});
